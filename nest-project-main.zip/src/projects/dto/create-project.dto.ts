
export class CreateProjectDto {
    name:string
}
