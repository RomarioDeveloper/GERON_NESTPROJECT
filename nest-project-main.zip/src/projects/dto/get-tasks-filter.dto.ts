export class GetTasksFilterDto{
    userId?:string
    projectId?:string
}