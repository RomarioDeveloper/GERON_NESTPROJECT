
export class CreateTaskDto{
    title:string;
    startDate:string;
    endDate:string;
    userID: string;
    projectID:string;
}