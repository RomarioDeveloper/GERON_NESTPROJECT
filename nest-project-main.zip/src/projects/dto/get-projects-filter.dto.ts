export class GetProjectsFilterDto{
    userId?:string
}