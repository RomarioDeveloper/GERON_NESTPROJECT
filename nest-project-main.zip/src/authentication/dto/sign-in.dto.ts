export class SignInDTO {
  username: string;
  password: string;
}
