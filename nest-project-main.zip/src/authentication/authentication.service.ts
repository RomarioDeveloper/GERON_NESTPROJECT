import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { SignInDTO } from './dto/sign-in.dto';
import { CreateUserDto } from 'src/users/dto/create-user.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from 'src/users/entities/user.entity';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthenticationService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  async signIn(SignInDTO: SignInDTO) {
    const user = await this.userRepository.findOne({
      where: {
        username: SignInDTO.username,
      },
    });

    if (!user) {
      throw new HttpException('Пользователь не найден', HttpStatus.NOT_FOUND);
    }

    const isMatch = await bcrypt.compare(SignInDTO.password, user.password);

    if (isMatch) {
      throw new HttpException('Некорректный пароль', HttpStatus.UNAUTHORIZED);
    }

    return 'Пользователь авторизован ';
  }

  async signUp(createUserDto: CreateUserDto) {
    const salt = await bcrypt.genSalt();
    const hash = await bcrypt.hash(createUserDto.password, salt);

    const user = new User({ ...createUserDto, password: hash });
    await this.userRepository.save(user);

    return 'Добавлен новый пользователь';
  }
}
