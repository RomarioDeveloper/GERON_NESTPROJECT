export class CreateAddressDto{
    country: string;
    city: string;
    street: string;
    house: string;
}